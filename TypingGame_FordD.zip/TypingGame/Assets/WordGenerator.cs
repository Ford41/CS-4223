﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class WordGenerator : MonoBehaviour {

    private static string[] wordList = {"side", "robin", "three", "protect", "somber", "jump", "pretty", "danger", "happy",
    "sad", "realistic", "productive", "increase", "why", "reduce", "destroy", "return", "loop", "function", "method", "end"};
    //insert word list here or file to be read + other things

    public static string GetRandomWord()
    {
        int randomIndex = Random.Range(0, wordList.Length);
        string randomWord = wordList[randomIndex];

        return randomWord;
    }
	
}
